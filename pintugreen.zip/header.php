<header id="header" class="header-transparent">
    <div class="container-fluid">

      <div class="row justify-content-center">
        <div class="col-xl-11 d-flex align-items-center">

            <a href="index.php"  class="mr-auto">
             <img src="assets/img/logo.png" width="120px" alt="" class="img-fluid">
            </a>

          <nav class="nav-menu d-none d-lg-block">
            <ul>
              <li class=""><a href="index.php">Inicio</a></li>
              <li><a href="index.php#nosotros">Quienes somos</a></li>
              <li><a href="index.php#promo">Promociones</a></li>
              <li class="drop-down"><a href="#about">Servicios</a>
                <ul>
                  <li><a href="index.php#drywall">Reparacion de drywall </a></li>
                  <li><a href="index.php#estuco">Reparacion de estuco</a></li>
                  <li><a href="index.php#pintura">Pintura interior y exterior</a></li>
                  <li><a href="index.php#trafico">Pintura de trafico </a></li>
                  <li><a href="index.php#epoxica">Pintura epoxica </a></li>
                  <li><a href="index.php#demarcacion">Demarcacion  </a></li>
                </ul>
              </li>
              <li><a href="index.php#contact">Contactanos</a></li>
              <li><a href="cotizacion.php">Cotización</a></li>
              <li><a target="_blank" href="https://checkout.wompi.co/l/YQ6IZD">Pagar</a></li>

            </ul>
          </nav><!-- .nav-menu -->
        </div>
      </div>

    </div>
  </header>