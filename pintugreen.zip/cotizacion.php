<?php 

  require_once("head.php");
  require_once("contenido_cotizacion.php");
  require_once("footer.php");

?>