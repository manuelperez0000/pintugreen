<?php 

  require_once("head.php");
  require_once("contenido.php");
  require_once("footer.php");

?>